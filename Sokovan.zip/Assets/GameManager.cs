﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    public GameObject winUI;
    public ItemBox[] itemBoxes;
    public bool isGameOver;
	// Use this for initialization
	void Start () {
        isGameOver = false;
	}
	
	// Update is called once per frame
	void Update () {

        if(Input.GetKeyDown(KeyCode.Space)) // 키보드를 누르는 그 순간
        {
            SceneManager.LoadScene("Main");
            //SceneManager.LoadScene(0); // 순번
        }
        if (isGameOver == true)
        {
            return;
        }
        int count = 0;
		for (int i = 0; i < 3; i++)
        {
            if (itemBoxes[i].isOveraped)
            {
                count++;
            }
        }

        if (count>=3)
        {
            isGameOver = true;
            winUI.SetActive(true);
            Debug.Log("Victory");
        }
	}
}
