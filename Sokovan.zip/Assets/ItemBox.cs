﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemBox : MonoBehaviour {

    public bool isOveraped = false;
    private Renderer myRenderer;
    // unity inspector에서 편집 가능
    public Color touchColor; // 그래서 편집기에서 편집된 컬러 색상 정보가 touchColor에 저장됨

    private Color originalColor;
    // Use this for initialization
    void Start() {
        myRenderer = GetComponent<Renderer>();
        originalColor = myRenderer.material.color;

    }

    // Update is called once per frame
    void Update() {

    }

    // 트리거인 콜라이더와 충돌할때 자동으로 실행
    // Enter 충돌을 한 순간
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "EndPoint")
        {
            isOveraped = true;
            myRenderer.material.color = touchColor;
        }

    }
    // Exit 붙어 있다가 떨어질때,
    void OnTriggerExit(Collider other)
    {
        if (other.tag == "EndPoint")
        {
            isOveraped = false;
            myRenderer.material.color = originalColor;
        }
    }

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "EndPoint")
        {
            isOveraped = true;
            myRenderer.material.color = touchColor;
        }
    }
    //void OnCollisionEnter(Collision other)
    //{
    //    Debug.Log("collision 충돌");
    //}
}
