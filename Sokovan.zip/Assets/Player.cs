﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public GameManager gameManager;
    // default is private 
    public float speed = 10f;
    private Rigidbody playerRigidbody;
	// Use this for initialization
	void Start () {
        playerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update() {
        float inputX = Input.GetAxis("Horizontal");
        float inputZ = Input.GetAxis("Vertical");
        float fallSpeed = playerRigidbody.velocity.y;

        if (gameManager.isGameOver)
        {
            return;
        }

        //playerRigidbody.AddForce(inputX * speed, 0, inputZ * speed);
        Vector3 velocity = new Vector3(inputX, 0, inputZ);
        velocity *= speed;
        velocity.y = fallSpeed;
        playerRigidbody.velocity = velocity;
    }
}
